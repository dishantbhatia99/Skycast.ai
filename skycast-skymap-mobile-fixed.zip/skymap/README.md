# SkyCast AI Sky Map — mobile-friendly version

This version avoids loading an unofficial JavaScript/WASM engine API directly inside the page. It embeds the official Stellarium Web site and provides a clear fallback button to open it directly if the phone/browser blocks iframe embedding.

## Upload to GitHub Pages
1. Extract this ZIP.
2. In `dishantbhatia99/skycast`, open or create the `skymap` folder.
3. Upload `index.html` from this folder and commit.
4. Visit `https://dishantbhatia99.github.io/skycast/skymap/`.

## Important
- If the embedded map is blank on your phone, tap **Open full Stellarium**. Some sites prevent embedding on other domains.
- City/coordinate fields in this lightweight wrapper do not automatically configure the official Stellarium app/site. Set observer location and date/time inside Stellarium itself for accurate sky simulation.
- The map is an astronomy planetarium, not a weather forecast. Cloud and visibility data are linked as a separate search.
